Xidian-Secret
=============

Xidian Secret in web, built with Django. 

It aims to provide a platform for students in Xidian University to share their secrets anonymously.

Just in PROGRESS......
